function obtenerUsuarios() {
  return JSON.parse(localStorage.getItem("users")) || [];
}

function guardarUsuario(nom, apellidos, email, password, type) {
  let users = obtenerUsuarios();

  if (users.some((user) => user.email === email)) {
    alert("Este correo ya está registrado. Usa otro.");
    return false;
  }

  let newUser = { nom, apellidos, email, password, type };
  users.push(newUser);
  localStorage.setItem("users", JSON.stringify(users));
  return true;
}

function eliminarUsuario(email) {
  let users = obtenerUsuarios().filter((user) => user.email !== email);
  localStorage.setItem("users", JSON.stringify(users));
}

function iniciarSesion(email, password) {
  let users = obtenerUsuarios();
  let usuario = users.find((u) => u.email === email && u.password === password);
  if (usuario) {
    localStorage.setItem("loggedInUser", JSON.stringify(usuario));
    window.location.href =
      usuario.type === "admin" ? "admin.html" : "index.html";
  } else {
    alert("Usuario o contraseña incorrectos.");
  }
}

function cerrarSesion() {
  localStorage.removeItem("loggedInUser");
  window.location.href = "index.html";
}
