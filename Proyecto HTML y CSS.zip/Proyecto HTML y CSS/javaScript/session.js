document.addEventListener("DOMContentLoaded", function () {
  let user = JSON.parse(localStorage.getItem("loggedInUser"));

  // Bloqueo de acceso manual a admin.html para usuarios no administradores
  if (
    window.location.pathname.endsWith("admin.html") &&
    (!user || user.type !== "admin")
  ) {
    window.location.href = "index.html"; // Redirige si no es admin
  }

  // Mostrar/ocultar botón de logout según la sesión activa
  let logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.style.display = user ? "inline-block" : "none"; // Ajuste de estilo para mejor visibilidad
  }

  // Mostrar/ocultar el botón "Editor" en home.html según el tipo de usuario
  let editorBtn = document.getElementById("editorBtn")?.parentElement;
  if (editorBtn) {
    editorBtn.style.display =
      user && user.type === "admin" ? "inline-block" : "none";
  }
});
let timeout;
function resetTimer() {
  clearTimeout(timeout);
  timeout = setTimeout(() => {
    alert("Sesión cerrada por inactividad.");
    localStorage.removeItem("loggedInUser");
    window.location.href = "index.html";
  }, 120000);
}

document.addEventListener("mousemove", resetTimer);
document.addEventListener("keypress", resetTimer);
resetTimer();

// Función para cerrar sesión
document.getElementById("logoutBtn")?.addEventListener("click", function () {
  localStorage.removeItem("loggedInUser"); // Borra la sesión
  window.location.href = "index.html"; // Redirige al inicio
});
