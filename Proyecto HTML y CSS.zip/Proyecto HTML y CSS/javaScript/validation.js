document.addEventListener("DOMContentLoaded", function () {
  const emailInput = document.getElementById("email");
  const confirmEmailInput = document.getElementById("confirmEmail");
  const passwordInput = document.getElementById("password");
  const confirmPasswordInput = document.getElementById("confirm-password");
  const usernameField = document.getElementById("username"); // Nombre de usuario automático
  const togglePasswordBtn = document.getElementById("togglePassword");
  const registerBtn = document.getElementById("registroBtn");
  const passwordStrength = document.getElementById("passwordStrength");

  // 💡 Alternar visibilidad de contraseña
  togglePasswordBtn.addEventListener("click", function () {
    passwordInput.type =
      passwordInput.type === "password" ? "text" : "password";
    togglePasswordBtn.textContent =
      passwordInput.type === "password" ? "👁️ Mostrar" : "🔒 Ocultar";
  });

  // 🔒 Prohibir copy-paste en la contraseña
  passwordInput.addEventListener("paste", function (event) {
    event.preventDefault();
    alert("No puedes copiar-enganchar la contraseña por seguridad.");
  });

  // 💡 Generar nombre de usuario automático basado en el email
  emailInput.addEventListener("input", function () {
    usernameField.value = emailInput.value.split("@")[0];
  });

  // 📌 Validación en tiempo real
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordRegex =
    /^(?=.*[A-Z])(?=.*\d)(?=.*[\W_])[A-Za-z\d!@#$%^&*]{8,}$/;

  function validarInput(input, condicion, mensajeError) {
    let errorText = input.nextElementSibling;
    if (!errorText || !errorText.classList.contains("error-message")) {
      errorText = document.createElement("span");
      errorText.classList.add("error-message");
      input.parentNode.appendChild(errorText);
    }

    if (condicion) {
      input.style.border = "2px solid green";
      errorText.textContent = "";
    } else {
      input.style.border = "2px solid red";
      errorText.textContent = mensajeError;
      input.focus();
      input.classList.add("shake");
      setTimeout(() => input.classList.remove("shake"), 500);
    }
  }

  function mostrarFuerzaPassword(password) {
    let fuerza = password.length;
    passwordStrength.style.width = `${fuerza * 10}%`;
    passwordStrength.style.backgroundColor =
      fuerza > 8 ? "green" : fuerza > 5 ? "orange" : "red";
  }

  confirmPasswordInput.addEventListener("input", function () {
    validarInput(
      confirmPasswordInput,
      passwordInput.value === confirmPasswordInput.value,
      "Las contraseñas no coinciden."
    );
  });

  emailInput.addEventListener("input", function () {
    validarInput(
      emailInput,
      emailRegex.test(emailInput.value),
      "Email inválido."
    );
  });

  confirmEmailInput.addEventListener("input", function () {
    validarInput(
      confirmEmailInput,
      emailInput.value === confirmEmailInput.value,
      "Los emails no coinciden."
    );
  });

  document.querySelectorAll("input").forEach((input) => {
    input.addEventListener("input", function () {
      let emailValid =
        emailRegex.test(emailInput.value) &&
        emailInput.value === confirmEmailInput.value;
      let passwordValid =
        passwordRegex.test(passwordInput.value) &&
        passwordInput.value === confirmPasswordInput.value;
      let userTypeSelected =
        document.querySelector("input[name='user_type']:checked") !== null;
      registerBtn.disabled = !(emailValid && passwordValid && userTypeSelected);
    });
  });
});
