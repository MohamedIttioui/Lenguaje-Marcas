document.getElementById("registroBtn").addEventListener("click", function () {
  const form = document.querySelector("form");
  const inputNom = form["nom"].value.trim();
  const inputApellidos = form["apellidos"].value.trim();
  const inputEmail = form["email"].value.trim();
  const inputPassword = form["password"].value.trim();
  const inputUserType = document.querySelector(
    "input[name='user_type']:checked"
  )?.value;

  let users = JSON.parse(localStorage.getItem("users")) || [];

  if (users.some((user) => user.email === inputEmail)) {
    alert("Este correo ya está registrado. Usa otro.");
    return;
  }

  let newUser = {
    nom: inputNom,
    apellidos: inputApellidos,
    email: inputEmail,
    password: inputPassword,
    type: inputUserType,
  };

  users.push(newUser);
  localStorage.setItem("users", JSON.stringify(users));

  alert("Registro exitoso.");
  window.location.href =
    inputUserType === "admin" ? "admin.html" : "index.html";
});
